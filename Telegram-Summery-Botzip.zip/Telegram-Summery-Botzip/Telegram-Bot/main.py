import sqlite3
import feedparser
import asyncio
import os
import requests
from datetime import datetime
from threading import Thread
from flask import Flask
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    ContextTypes,
    filters,
)
from utils import get_image, build_caption, download_image, build_full_article, split_message

TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "7978043954:AAFoFI8re-GOodFu5VlsxnstINRjfRyEDqY")
CHANNEL_ID = os.environ.get("TELEGRAM_CHANNEL_ID", "-1002446943144")
CHANNEL_USERNAME = os.environ.get("TELEGRAM_CHANNEL_USERNAME", "WhatsApp_Updates_X")
ADMIN_ID = int(os.environ.get("TELEGRAM_ADMIN_ID", "5095434008"))
FEED_URL = "https://wabetainfo.com/feed/"
CHECK_INTERVAL = 300
DB_FILE = "posts_history.db"

CATEGORIES = ["Android", "iOS", "Windows", "Web", "General"]

USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

def fetch_rss_feed():
    try:
        response = requests.get(FEED_URL, headers={"User-Agent": USER_AGENT}, timeout=15)
        if response.status_code == 200:
            return feedparser.parse(response.content)
    except Exception as e:
        print(f"Error fetching RSS feed: {e}")
    return feedparser.parse(FEED_URL)

def db_connect():
    return sqlite3.connect(DB_FILE)

def has_post(post_id):
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("SELECT id FROM posts WHERE id=?", (post_id,))
    row = cur.fetchone()
    conn.close()
    return row is not None

def save_post(post_id, title, link, published, category="General", channel_message_id=None):
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("""
        INSERT OR IGNORE INTO posts (id, title, link, published, category, channel_message_id)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (post_id, title, link, published, category, channel_message_id))
    conn.commit()
    conn.close()

def update_post_message_id(post_id, channel_message_id):
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("UPDATE posts SET channel_message_id=? WHERE id=?", (channel_message_id, post_id))
    conn.commit()
    conn.close()

def increment_share_count(post_id, user_id=None):
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("UPDATE posts SET share_count = share_count + 1 WHERE id=?", (post_id,))
    if user_id:
        cur.execute("INSERT OR IGNORE INTO post_shares (user_id, post_id) VALUES (?, ?)", (user_id, post_id))
    conn.commit()
    conn.close()

def get_stats():
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM posts")
    posts_count = cur.fetchone()[0]
    cur.execute("SELECT COUNT(DISTINCT user_id) FROM user_profiles")
    users_count = cur.fetchone()[0]
    cur.execute("SELECT title, share_count FROM posts ORDER BY share_count DESC LIMIT 5")
    top_posts = cur.fetchall()
    conn.close()
    return posts_count, users_count, top_posts

def get_or_create_user(user_id, username=None, first_name=None):
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("SELECT user_id FROM user_profiles WHERE user_id=?", (user_id,))
    row = cur.fetchone()
    if not row:
        cur.execute("""
            INSERT INTO user_profiles (user_id, username, first_name)
            VALUES (?, ?, ?)
        """, (user_id, username, first_name))
        conn.commit()
    else:
        cur.execute("UPDATE user_profiles SET last_active=CURRENT_TIMESTAMP WHERE user_id=?", (user_id,))
        conn.commit()
    conn.close()

def get_user_profile(user_id):
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("SELECT * FROM user_profiles WHERE user_id=?", (user_id,))
    profile = cur.fetchone()
    cur.execute("SELECT COUNT(*) FROM post_shares WHERE user_id=?", (user_id,))
    shares = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM bookmarks WHERE user_id=?", (user_id,))
    bookmarks = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM subscriptions WHERE user_id=?", (user_id,))
    subs = cur.fetchone()[0]
    conn.close()
    return profile, shares, bookmarks, subs

def get_user_subscriptions(user_id):
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("SELECT category FROM subscriptions WHERE user_id=?", (user_id,))
    rows = cur.fetchall()
    conn.close()
    return [r[0] for r in rows]

def toggle_subscription(user_id, category):
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("SELECT * FROM subscriptions WHERE user_id=? AND category=?", (user_id, category))
    if cur.fetchone():
        cur.execute("DELETE FROM subscriptions WHERE user_id=? AND category=?", (user_id, category))
        result = False
    else:
        cur.execute("INSERT INTO subscriptions (user_id, category) VALUES (?, ?)", (user_id, category))
        result = True
    conn.commit()
    conn.close()
    return result

def get_user_bookmarks(user_id, limit=10, offset=0):
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("""
        SELECT p.id, p.title, p.link, p.category 
        FROM bookmarks b 
        JOIN posts p ON b.post_id = p.id 
        WHERE b.user_id=? 
        ORDER BY b.bookmarked_at DESC 
        LIMIT ? OFFSET ?
    """, (user_id, limit, offset))
    rows = cur.fetchall()
    conn.close()
    return rows

def toggle_bookmark(user_id, post_id):
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("SELECT * FROM bookmarks WHERE user_id=? AND post_id=?", (user_id, post_id))
    if cur.fetchone():
        cur.execute("DELETE FROM bookmarks WHERE user_id=? AND post_id=?", (user_id, post_id))
        result = False
    else:
        cur.execute("INSERT INTO bookmarks (user_id, post_id) VALUES (?, ?)", (user_id, post_id))
        result = True
    conn.commit()
    conn.close()
    return result

def is_bookmarked(user_id, post_id):
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("SELECT * FROM bookmarks WHERE user_id=? AND post_id=?", (user_id, post_id))
    result = cur.fetchone() is not None
    conn.close()
    return result

def get_recent_posts(limit=10, offset=0, category=None):
    conn = db_connect()
    cur = conn.cursor()
    if category:
        cur.execute("""
            SELECT id, title, link, category, share_count 
            FROM posts 
            WHERE category=?
            ORDER BY rowid DESC 
            LIMIT ? OFFSET ?
        """, (category, limit, offset))
    else:
        cur.execute("""
            SELECT id, title, link, category, share_count 
            FROM posts 
            ORDER BY rowid DESC 
            LIMIT ? OFFSET ?
        """, (limit, offset))
    rows = cur.fetchall()
    conn.close()
    return rows

def get_posts_count(category=None):
    conn = db_connect()
    cur = conn.cursor()
    if category:
        cur.execute("SELECT COUNT(*) FROM posts WHERE category=?", (category,))
    else:
        cur.execute("SELECT COUNT(*) FROM posts")
    count = cur.fetchone()[0]
    conn.close()
    return count

def save_feedback(user_id, message):
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("INSERT INTO feedback (user_id, message) VALUES (?, ?)", (user_id, message))
    conn.commit()
    conn.close()

def get_pending_feedback():
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("SELECT id, user_id, message, created_at FROM feedback WHERE status='pending' ORDER BY created_at DESC LIMIT 10")
    rows = cur.fetchall()
    conn.close()
    return rows

def toggle_notifications(user_id):
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("SELECT notifications_enabled FROM user_profiles WHERE user_id=?", (user_id,))
    row = cur.fetchone()
    if row:
        new_val = 0 if row[0] == 1 else 1
        cur.execute("UPDATE user_profiles SET notifications_enabled=? WHERE user_id=?", (new_val, user_id))
        conn.commit()
        result = new_val == 1
    else:
        result = True
    conn.close()
    return result

def get_notifications_status(user_id):
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("SELECT notifications_enabled FROM user_profiles WHERE user_id=?", (user_id,))
    row = cur.fetchone()
    conn.close()
    return row[0] == 1 if row else True

def get_subscribed_users(category):
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("""
        SELECT s.user_id FROM subscriptions s 
        JOIN user_profiles u ON s.user_id = u.user_id 
        WHERE s.category=? AND u.notifications_enabled=1
    """, (category,))
    rows = cur.fetchall()
    conn.close()
    return [r[0] for r in rows]

def log_activity(user_id, action):
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("INSERT INTO user_activity (user_id, action) VALUES (?, ?)", (user_id, action))
    conn.commit()
    conn.close()

def get_admin_stats():
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM user_profiles")
    total_users = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM posts")
    total_posts = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM bookmarks")
    total_bookmarks = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM post_shares")
    total_shares = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM feedback WHERE status='pending'")
    pending_feedback = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM user_activity WHERE created_at >= datetime('now', '-1 day')")
    daily_activity = cur.fetchone()[0]
    conn.close()
    return {
        "users": total_users,
        "posts": total_posts,
        "bookmarks": total_bookmarks,
        "shares": total_shares,
        "pending_feedback": pending_feedback,
        "daily_activity": daily_activity
    }

app = Flask("")

@app.route("/")
def home():
    return "Advanced Bot Online!"

def run_flask():
    app.run(host="0.0.0.0", port=5000)

def keep_alive():
    Thread(target=run_flask).start()

waiting_for_feedback = {}

async def start_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    get_or_create_user(user.id, user.username, user.first_name)
    log_activity(user.id, "start")
    
    welcome_text = f"""
📱 <b>Welcome to WABeta News Bot!</b>

━━━━━━━━━━━━━━━

👋 Hello <b>{user.first_name}</b>!

Stay updated with the latest WhatsApp news, beta updates, and features across all platforms.

━━━━━━━━━━━━━━━
✨ <b>What I can do:</b>
━━━━━━━━━━━━━━━

📰 Browse latest news
🔔 Subscribe to categories
🔖 Bookmark favorite articles
📊 Track your activity
💬 Get instant notifications

👇 Tap the button below to explore!
"""
    keyboard = [
        [InlineKeyboardButton("🚀 Open Main Menu", callback_data="main_menu")],
    ]
    await update.message.reply_text(
        welcome_text, 
        parse_mode="HTML", 
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def panel_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_main_menu(update.message, update.effective_user.id)

async def test_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id != ADMIN_ID:
        await update.message.reply_text("This command is only for admins.")
        return
    
    await update.message.reply_text("Fetching latest post from WABeta News...")
    
    try:
        feed = fetch_rss_feed()
        if not feed.entries:
            await update.message.reply_text("No posts found in the RSS feed.")
            return
        
        latest = feed.entries[0]
        caption, categories = build_caption(latest)
        full_article, _ = build_full_article(latest)
        
        save_post(
            latest.id,
            getattr(latest, "title", ""),
            getattr(latest, "link", ""),
            getattr(latest, "published", ""),
            categories[0] if categories else "General",
        )
        
        image_data = download_image(latest)
        if image_data:
            if len(full_article) > 1024:
                full_article = full_article[:1021] + "..."
            
            sent_msg = await context.bot.send_photo(
                chat_id=CHANNEL_ID,
                photo=image_data,
                caption=full_article,
                parse_mode="HTML",
            )
            
            update_post_message_id(latest.id, sent_msg.message_id)
            
            await update.message.reply_text(f"Latest post sent to channel!\n\nTitle: {latest.title}")
        else:
            await update.message.reply_text("Could not download image. Please try again.")
    except Exception as e:
        await update.message.reply_text(f"Error: {str(e)}")

async def show_main_menu(message_or_query, user_id, edit=False):
    menu_text = """
📱 <b>WABeta News Bot</b>

━━━━━━━━━━━━━━━
🏠 <b>Main Menu</b>
━━━━━━━━━━━━━━━

Choose an option below:
"""
    keyboard = [
        [
            InlineKeyboardButton("📰 Latest News", callback_data="menu_news"),
            InlineKeyboardButton("📂 Categories", callback_data="menu_categories"),
        ],
        [
            InlineKeyboardButton("👤 My Profile", callback_data="menu_profile"),
            InlineKeyboardButton("🔖 Bookmarks", callback_data="menu_bookmarks"),
        ],
        [
            InlineKeyboardButton("🔔 Subscriptions", callback_data="menu_subscriptions"),
            InlineKeyboardButton("⚙️ Settings", callback_data="menu_settings"),
        ],
        [
            InlineKeyboardButton("📊 Channel Stats", callback_data="menu_stats"),
            InlineKeyboardButton("ℹ️ About", callback_data="menu_about"),
        ],
        [InlineKeyboardButton("💬 Send Feedback", callback_data="menu_feedback")],
    ]
    
    if user_id == ADMIN_ID:
        keyboard.append([InlineKeyboardButton("🔐 Admin Panel", callback_data="admin_panel")])
    
    if edit:
        await message_or_query.edit_message_text(
            menu_text, 
            parse_mode="HTML", 
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
    else:
        await message_or_query.reply_text(
            menu_text, 
            parse_mode="HTML", 
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

async def callback_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    user_id = query.from_user.id
    
    get_or_create_user(user_id, query.from_user.username, query.from_user.first_name)
    
    if data == "main_menu":
        if user_id in waiting_for_feedback:
            del waiting_for_feedback[user_id]
        if user_id in waiting_for_broadcast:
            del waiting_for_broadcast[user_id]
        await show_main_menu(query, user_id, edit=True)
        return
    
    if data == "admin_panel":
        if user_id in waiting_for_broadcast:
            del waiting_for_broadcast[user_id]
    
    if data == "menu_news":
        await show_news_menu(query, user_id, page=0)
        return
    
    if data.startswith("news_page_"):
        page = int(data.split("_")[2])
        await show_news_menu(query, user_id, page=page)
        return
    
    if data.startswith("news_cat_"):
        parts = data.split("_")
        cat = parts[2]
        page = int(parts[3]) if len(parts) > 3 else 0
        await show_category_news(query, user_id, cat, page)
        return
    
    if data == "menu_categories":
        await show_categories_menu(query)
        return
    
    if data == "menu_profile":
        await show_profile(query, user_id)
        return
    
    if data == "menu_bookmarks":
        await show_bookmarks(query, user_id, page=0)
        return
    
    if data.startswith("bookmarks_page_"):
        page = int(data.split("_")[2])
        await show_bookmarks(query, user_id, page=page)
        return
    
    if data.startswith("bookmark_"):
        post_id = data[9:]
        added = toggle_bookmark(user_id, post_id)
        status = "added to" if added else "removed from"
        await query.answer(f"Post {status} bookmarks!", show_alert=True)
        return
    
    if data == "menu_subscriptions":
        await show_subscriptions(query, user_id)
        return
    
    if data.startswith("toggle_sub_"):
        category = data[11:]
        subscribed = toggle_subscription(user_id, category)
        status = "subscribed to" if subscribed else "unsubscribed from"
        await query.answer(f"You {status} {category}!", show_alert=True)
        await show_subscriptions(query, user_id)
        return
    
    if data == "menu_settings":
        await show_settings(query, user_id)
        return
    
    if data == "toggle_notifications":
        enabled = toggle_notifications(user_id)
        status = "enabled" if enabled else "disabled"
        await query.answer(f"Notifications {status}!", show_alert=True)
        await show_settings(query, user_id)
        return
    
    if data == "menu_stats":
        await show_channel_stats(query)
        return
    
    if data == "menu_about":
        await show_about(query)
        return
    
    if data == "menu_feedback":
        await show_feedback_prompt(query, user_id)
        return
    
    if data.startswith("view_post_"):
        post_id = data[10:]
        await show_post_detail(query, user_id, post_id)
        return
    
    if data.startswith("share_post_"):
        post_id = data[11:]
        conn = db_connect()
        cur = conn.cursor()
        cur.execute("SELECT title, link, channel_message_id FROM posts WHERE id=?", (post_id,))
        post = cur.fetchone()
        conn.close()
        
        if post:
            title, link, channel_msg_id = post
            
            if channel_msg_id:
                post_link = f"https://t.me/{CHANNEL_USERNAME}/{channel_msg_id}"
            else:
                post_link = f"https://t.me/{CHANNEL_USERNAME}"
            
            share_text = f"📰 {title}\n\n🔗 Read more: {post_link}\n\n📢 Join @{CHANNEL_USERNAME} for more WhatsApp news!"
            
            increment_share_count(post_id, user_id)
            
            await query.message.reply_text(
                f"<b>Share this post:</b>\n\n{share_text}\n\n👆 <i>Forward this message to share with friends!</i>",
                parse_mode="HTML"
            )
            await query.answer("Share message sent! Forward it to share.", show_alert=True)
        else:
            await query.answer("Post not found!", show_alert=True)
        return
    
    if data == "admin_panel" and user_id == ADMIN_ID:
        await show_admin_panel(query)
        return
    
    if data == "admin_feedback" and user_id == ADMIN_ID:
        await show_admin_feedback(query)
        return
    
    if data == "admin_users" and user_id == ADMIN_ID:
        await show_admin_users(query)
        return
    
    if data == "admin_refresh" and user_id == ADMIN_ID:
        await query.answer("Refreshing feed...", show_alert=False)
        try:
            await process_feed(query._bot.application if hasattr(query._bot, 'application') else None)
            await query.answer("Feed refreshed successfully!", show_alert=True)
        except Exception as e:
            await query.answer(f"Error: {str(e)[:50]}", show_alert=True)
        return
    
    if data == "admin_test_post" and user_id == ADMIN_ID:
        await admin_send_test_post(query)
        return
    
    if data == "admin_broadcast" and user_id == ADMIN_ID:
        await show_broadcast_prompt(query, user_id)
        return

async def show_news_menu(query, user_id, page=0):
    posts = get_recent_posts(limit=5, offset=page*5)
    total = get_posts_count()
    total_pages = (total + 4) // 5
    
    if not posts:
        text = "<b>Latest News</b>\n\nNo posts available yet."
        keyboard = [[InlineKeyboardButton("Back to Menu", callback_data="main_menu")]]
    else:
        text = f"<b>Latest News</b> (Page {page+1}/{total_pages})\n\n"
        keyboard = []
        for post in posts:
            post_id, title, link, category, shares = post
            short_title = title[:30] + "..." if len(title) > 30 else title
            keyboard.append([InlineKeyboardButton(f"{short_title}", callback_data=f"view_post_{post_id}")])
        
        nav_buttons = []
        if page > 0:
            nav_buttons.append(InlineKeyboardButton("Previous", callback_data=f"news_page_{page-1}"))
        if page < total_pages - 1:
            nav_buttons.append(InlineKeyboardButton("Next", callback_data=f"news_page_{page+1}"))
        if nav_buttons:
            keyboard.append(nav_buttons)
        
        keyboard.append([InlineKeyboardButton("Back to Menu", callback_data="main_menu")])
    
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))

async def show_categories_menu(query):
    text = "<b>Browse by Category</b>\n\nSelect a category to view posts:"
    keyboard = []
    for cat in CATEGORIES:
        count = get_posts_count(cat)
        keyboard.append([InlineKeyboardButton(f"{cat} ({count} posts)", callback_data=f"news_cat_{cat}_0")])
    keyboard.append([InlineKeyboardButton("Back to Menu", callback_data="main_menu")])
    
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))

async def show_category_news(query, user_id, category, page=0):
    posts = get_recent_posts(limit=5, offset=page*5, category=category)
    total = get_posts_count(category)
    total_pages = max(1, (total + 4) // 5)
    
    if not posts:
        text = f"<b>{category} News</b>\n\nNo posts in this category yet."
    else:
        text = f"<b>{category} News</b> (Page {page+1}/{total_pages})\n\n"
    
    keyboard = []
    for post in posts:
        post_id, title, link, cat, shares = post
        short_title = title[:30] + "..." if len(title) > 30 else title
        keyboard.append([InlineKeyboardButton(f"{short_title}", callback_data=f"view_post_{post_id}")])
    
    nav_buttons = []
    if page > 0:
        nav_buttons.append(InlineKeyboardButton("Previous", callback_data=f"news_cat_{category}_{page-1}"))
    if page < total_pages - 1:
        nav_buttons.append(InlineKeyboardButton("Next", callback_data=f"news_cat_{category}_{page+1}"))
    if nav_buttons:
        keyboard.append(nav_buttons)
    
    keyboard.append([InlineKeyboardButton("Back to Categories", callback_data="menu_categories")])
    keyboard.append([InlineKeyboardButton("Back to Menu", callback_data="main_menu")])
    
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))

async def show_post_detail(query, user_id, post_id):
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("SELECT id, title, link, category, share_count FROM posts WHERE id=?", (post_id,))
    post = cur.fetchone()
    conn.close()
    
    if not post:
        await query.edit_message_text("Post not found.")
        return
    
    pid, title, link, category, shares = post
    bookmarked = is_bookmarked(user_id, post_id)
    bookmark_text = "Remove Bookmark" if bookmarked else "Add Bookmark"
    
    text = f"""
<b>{title}</b>

Category: {category}
Shares: {shares}

<a href='{link}'>Read Full Article</a>
"""
    keyboard = [
        [
            InlineKeyboardButton(bookmark_text, callback_data=f"bookmark_{post_id}"),
            InlineKeyboardButton("Share", callback_data=f"share_post_{post_id}"),
        ],
        [InlineKeyboardButton("Back to News", callback_data="menu_news")],
        [InlineKeyboardButton("Back to Menu", callback_data="main_menu")],
    ]
    
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))

async def show_profile(query, user_id):
    profile, shares, bookmarks, subs = get_user_profile(user_id)
    
    if profile:
        user_id_db, username, first_name, joined, notif, lang, last_active = profile
        joined_str = joined[:10] if joined else "Unknown"
    else:
        first_name = query.from_user.first_name
        joined_str = "Today"
    
    text = f"""
<b>My Profile</b>

Name: {first_name}
Member Since: {joined_str}

<b>Your Activity:</b>
Posts Shared: {shares}
Bookmarked: {bookmarks}
Subscriptions: {subs}

Keep engaging to see your stats grow!
"""
    keyboard = [
        [InlineKeyboardButton("My Bookmarks", callback_data="menu_bookmarks")],
        [InlineKeyboardButton("My Subscriptions", callback_data="menu_subscriptions")],
        [InlineKeyboardButton("Back to Menu", callback_data="main_menu")],
    ]
    
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))

async def show_bookmarks(query, user_id, page=0):
    bookmarks = get_user_bookmarks(user_id, limit=5, offset=page*5)
    
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM bookmarks WHERE user_id=?", (user_id,))
    total = cur.fetchone()[0]
    conn.close()
    
    total_pages = max(1, (total + 4) // 5)
    
    if not bookmarks:
        text = "<b>My Bookmarks</b>\n\nYou haven't bookmarked any posts yet.\nBrowse news and bookmark your favorites!"
        keyboard = [[InlineKeyboardButton("Browse News", callback_data="menu_news")]]
    else:
        text = f"<b>My Bookmarks</b> (Page {page+1}/{total_pages})\n\n"
        keyboard = []
        for bm in bookmarks:
            post_id, title, link, category = bm
            short_title = title[:30] + "..." if len(title) > 30 else title
            keyboard.append([InlineKeyboardButton(f"{short_title}", callback_data=f"view_post_{post_id}")])
        
        nav_buttons = []
        if page > 0:
            nav_buttons.append(InlineKeyboardButton("Previous", callback_data=f"bookmarks_page_{page-1}"))
        if page < total_pages - 1:
            nav_buttons.append(InlineKeyboardButton("Next", callback_data=f"bookmarks_page_{page+1}"))
        if nav_buttons:
            keyboard.append(nav_buttons)
    
    keyboard.append([InlineKeyboardButton("Back to Menu", callback_data="main_menu")])
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))

async def show_subscriptions(query, user_id):
    user_subs = get_user_subscriptions(user_id)
    
    text = """
<b>Manage Subscriptions</b>

Subscribe to categories to receive notifications when new posts are published.

Tap a category to toggle:
"""
    keyboard = []
    for cat in CATEGORIES:
        status = " [Subscribed]" if cat in user_subs else ""
        keyboard.append([InlineKeyboardButton(f"{cat}{status}", callback_data=f"toggle_sub_{cat}")])
    
    keyboard.append([InlineKeyboardButton("Back to Menu", callback_data="main_menu")])
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))

async def show_settings(query, user_id):
    notif_enabled = get_notifications_status(user_id)
    notif_status = "ON" if notif_enabled else "OFF"
    notif_btn_text = "Turn Off Notifications" if notif_enabled else "Turn On Notifications"
    
    text = f"""
<b>Settings</b>

<b>Notifications:</b> {notif_status}

Configure your preferences below:
"""
    keyboard = [
        [InlineKeyboardButton(notif_btn_text, callback_data="toggle_notifications")],
        [InlineKeyboardButton("Manage Subscriptions", callback_data="menu_subscriptions")],
        [InlineKeyboardButton("Back to Menu", callback_data="main_menu")],
    ]
    
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))

async def show_channel_stats(query):
    posts_count, users_count, top_posts = get_stats()
    
    top_text = ""
    for i, (title, count) in enumerate(top_posts, 1):
        short_title = title[:25] + "..." if len(title) > 25 else title
        top_text += f"{i}. {short_title} ({count} shares)\n"
    
    if not top_text:
        top_text = "No shared posts yet"
    
    text = f"""
<b>Channel Statistics</b>

Total Posts: {posts_count}
Total Users: {users_count}

<b>Top Shared Posts:</b>
{top_text}
"""
    keyboard = [[InlineKeyboardButton("Back to Menu", callback_data="main_menu")]]
    
    if query.from_user.id == ADMIN_ID:
        keyboard.insert(0, [InlineKeyboardButton("Admin Panel", callback_data="admin_panel")])
    
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))

async def show_about(query):
    text = """
<b>About WABeta News Bot</b>

Version: 2.0

This bot provides the latest WhatsApp news and beta updates from WABeta News.

<b>Features:</b>
- Automatic news updates
- Category subscriptions
- Bookmark favorite posts
- Personal activity tracking
- Push notifications

<b>Developed by:</b>
Dev Modz Beta Developers

<b>Contact:</b>
Instagram: @senula_2007
WhatsApp: +94 71 072 5732
"""
    keyboard = [
        [InlineKeyboardButton("Instagram", url="https://instagram.com/senula_2007")],
        [InlineKeyboardButton("WhatsApp", url="https://wa.me/94710725732")],
        [InlineKeyboardButton("YouTube", url="https://youtube.com/Dev_Modz_Beta_Developers")],
        [InlineKeyboardButton("Back to Menu", callback_data="main_menu")],
    ]
    
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))

async def show_feedback_prompt(query, user_id):
    waiting_for_feedback[user_id] = True
    
    text = """
<b>Send Feedback</b>

We'd love to hear from you!

Please type your feedback message and send it. Your message will be reviewed by our team.
"""
    keyboard = [[InlineKeyboardButton("Cancel", callback_data="main_menu")]]
    
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))

async def handle_text_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.effective_user:
        return
    user_id = update.effective_user.id
    
    if user_id in waiting_for_feedback and waiting_for_feedback[user_id]:
        message = update.message.text
        save_feedback(user_id, message)
        waiting_for_feedback[user_id] = False
        
        await update.message.reply_text(
            "✅ Thank you for your feedback! Our team will review it soon.",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🏠 Back to Menu", callback_data="main_menu")]])
        )
        return
    
    if user_id == ADMIN_ID and user_id in waiting_for_broadcast and waiting_for_broadcast[user_id]:
        broadcast_message = update.message.text
        waiting_for_broadcast[user_id] = False
        
        users = get_all_users()
        sent_count = 0
        failed_count = 0
        
        await update.message.reply_text("📤 Broadcasting message to all users...")
        
        for user in users:
            uid = user[0]
            try:
                await context.bot.send_message(
                    chat_id=uid,
                    text=f"📢 <b>Announcement</b>\n\n{broadcast_message}",
                    parse_mode="HTML"
                )
                sent_count += 1
            except Exception:
                failed_count += 1
        
        await update.message.reply_text(
            f"✅ Broadcast complete!\n\n📤 Sent: {sent_count}\n❌ Failed: {failed_count}",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back to Admin", callback_data="admin_panel")]])
        )
        return

async def show_admin_panel(query):
    stats = get_admin_stats()
    
    text = f"""
🔐 <b>Admin Dashboard</b>

━━━━━━━━━━━━━━━
📊 <b>Statistics Overview</b>
━━━━━━━━━━━━━━━

👥 Total Users: <code>{stats['users']}</code>
📰 Total Posts: <code>{stats['posts']}</code>
🔖 Total Bookmarks: <code>{stats['bookmarks']}</code>
🔄 Total Shares: <code>{stats['shares']}</code>
💬 Pending Feedback: <code>{stats['pending_feedback']}</code>
📈 Activity (24h): <code>{stats['daily_activity']}</code>

━━━━━━━━━━━━━━━
⚙️ <b>Admin Controls</b>
━━━━━━━━━━━━━━━
"""
    keyboard = [
        [
            InlineKeyboardButton("📬 View Feedback", callback_data="admin_feedback"),
            InlineKeyboardButton("👥 View Users", callback_data="admin_users"),
        ],
        [
            InlineKeyboardButton("🔄 Force Refresh Feed", callback_data="admin_refresh"),
            InlineKeyboardButton("📤 Test Post", callback_data="admin_test_post"),
        ],
        [
            InlineKeyboardButton("📢 Broadcast Message", callback_data="admin_broadcast"),
        ],
        [InlineKeyboardButton("📊 Back to Stats", callback_data="menu_stats")],
        [InlineKeyboardButton("🏠 Back to Menu", callback_data="main_menu")],
    ]
    
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))

async def show_admin_feedback(query):
    feedback_list = get_pending_feedback()
    
    if not feedback_list:
        text = "<b>Pending Feedback</b>\n\nNo pending feedback."
    else:
        text = "<b>Pending Feedback</b>\n\n"
        for fb in feedback_list:
            fb_id, uid, msg, created = fb
            short_msg = msg[:50] + "..." if len(msg) > 50 else msg
            text += f"#{fb_id} (User {uid}): {short_msg}\n\n"
    
    keyboard = [
        [InlineKeyboardButton("Back to Admin", callback_data="admin_panel")],
        [InlineKeyboardButton("Back to Menu", callback_data="main_menu")],
    ]
    
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))

def get_all_users():
    conn = db_connect()
    cur = conn.cursor()
    cur.execute("SELECT user_id, username, first_name, joined_at FROM user_profiles ORDER BY joined_at DESC LIMIT 20")
    users = cur.fetchall()
    conn.close()
    return users

async def show_admin_users(query):
    users = get_all_users()
    
    if not users:
        text = "👥 <b>Users</b>\n\nNo users registered yet."
    else:
        text = f"👥 <b>Recent Users</b> (Showing last 20)\n\n"
        for i, user in enumerate(users, 1):
            uid, username, first_name, joined = user
            name = first_name or username or f"User {uid}"
            joined_date = joined[:10] if joined else "Unknown"
            text += f"{i}. <b>{name}</b> (ID: <code>{uid}</code>)\n   📅 Joined: {joined_date}\n\n"
    
    keyboard = [
        [InlineKeyboardButton("🔙 Back to Admin", callback_data="admin_panel")],
        [InlineKeyboardButton("🏠 Back to Menu", callback_data="main_menu")],
    ]
    
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))

async def admin_send_test_post(query):
    try:
        feed = fetch_rss_feed()
        if not feed.entries:
            await query.answer("No posts found in RSS feed!", show_alert=True)
            return
        
        latest = feed.entries[0]
        caption, categories = build_caption(latest)
        full_article, _ = build_full_article(latest)
        
        save_post(
            latest.id,
            getattr(latest, "title", ""),
            getattr(latest, "link", ""),
            getattr(latest, "published", ""),
            categories[0] if categories else "General",
        )
        
        image_data = download_image(latest)
        if image_data:
            if len(full_article) > 1024:
                full_article = full_article[:1021] + "..."
            
            await query._bot.send_photo(
                chat_id=CHANNEL_ID,
                photo=image_data,
                caption=full_article,
                parse_mode="HTML",
            )
            
            await query.answer("Test post sent!", show_alert=True)
        else:
            await query.answer("Could not download image!", show_alert=True)
    except Exception as e:
        await query.answer(f"Error: {str(e)[:50]}", show_alert=True)

waiting_for_broadcast = {}

async def show_broadcast_prompt(query, user_id):
    waiting_for_broadcast[user_id] = True
    
    text = """
📢 <b>Broadcast Message</b>

Send a message to all bot users.

<b>Type your message below:</b>
(It will be sent to all registered users)
"""
    keyboard = [[InlineKeyboardButton("❌ Cancel", callback_data="admin_panel")]]
    
    await query.edit_message_text(text, parse_mode="HTML", reply_markup=InlineKeyboardMarkup(keyboard))

async def process_feed(application):
    feed = fetch_rss_feed()

    for entry in feed.entries:
        post_id = entry.id

        if has_post(post_id):
            continue

        caption, categories = build_caption(entry)
        full_article, _ = build_full_article(entry)
        
        save_post(
            post_id,
            getattr(entry, "title", ""),
            getattr(entry, "link", ""),
            getattr(entry, "published", ""),
            categories[0] if categories else "General",
        )

        image_data = download_image(entry)
        if image_data:
            if len(full_article) > 1024:
                full_article = full_article[:1021] + "..."
            
            sent_msg = await application.bot.send_photo(
                chat_id=CHANNEL_ID,
                photo=image_data,
                caption=full_article,
                parse_mode="HTML",
            )
            
            update_post_message_id(post_id, sent_msg.message_id)

            for cat in categories:
                users = get_subscribed_users(cat)
                for uid in users:
                    try:
                        image_data_user = download_image(entry)
                        if image_data_user:
                            await application.bot.send_photo(
                                chat_id=uid,
                                photo=image_data_user,
                                caption=full_article,
                                parse_mode="HTML",
                            )
                    except Exception:
                        pass

async def send_latest_post_on_startup(application):
    feed = fetch_rss_feed()
    if not feed.entries:
        return

    latest = feed.entries[0]
    if has_post(latest.id):
        return

    caption, categories = build_caption(latest)
    full_article, _ = build_full_article(latest)
    save_post(latest.id, latest.title, latest.link, latest.published, categories[0] if categories else "General")

    image_data = download_image(latest)
    if image_data:
        if len(full_article) > 1024:
            full_article = full_article[:1021] + "..."
        
        sent_msg = await application.bot.send_photo(
            chat_id=CHANNEL_ID,
            photo=image_data,
            caption=full_article,
            parse_mode="HTML",
        )
        
        update_post_message_id(latest.id, sent_msg.message_id)

async def feed_loop(application):
    while True:
        try:
            await process_feed(application)
        except Exception:
            pass
        await asyncio.sleep(CHECK_INTERVAL)

async def check_feed_job(context: ContextTypes.DEFAULT_TYPE):
    await process_feed(context.application)

def main():
    if not TOKEN:
        print("Error: TELEGRAM_BOT_TOKEN environment variable not set")
        return
        
    application = ApplicationBuilder().token(TOKEN).build()

    application.add_handler(CommandHandler("start", start_cmd))
    application.add_handler(CommandHandler("panel", panel_cmd))
    application.add_handler(CommandHandler("menu", panel_cmd))
    application.add_handler(CommandHandler("test", test_cmd))
    application.add_handler(CallbackQueryHandler(callback_handler))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text_message))

    application.job_queue.run_repeating(
        check_feed_job,
        interval=CHECK_INTERVAL,
        first=10
    )

    application.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    keep_alive()
    main()
