import sqlite3

conn = sqlite3.connect("posts_history.db")
cur = conn.cursor()

# Posts table
cur.execute("""
CREATE TABLE IF NOT EXISTS posts (
    id TEXT PRIMARY KEY,
    title TEXT,
    link TEXT,
    published TEXT,
    share_count INTEGER DEFAULT 0,
    category TEXT,
    channel_message_id INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
""")

# Add channel_message_id column if not exists (for existing databases)
try:
    cur.execute("ALTER TABLE posts ADD COLUMN channel_message_id INTEGER")
except:
    pass

# User subscriptions
cur.execute("""
CREATE TABLE IF NOT EXISTS subscriptions (
    user_id INTEGER,
    category TEXT,
    PRIMARY KEY(user_id, category)
)
""")

# Per-user post shares
cur.execute("""
CREATE TABLE IF NOT EXISTS post_shares (
    user_id INTEGER,
    post_id TEXT,
    shared_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(user_id, post_id)
)
""")

# User profiles
cur.execute("""
CREATE TABLE IF NOT EXISTS user_profiles (
    user_id INTEGER PRIMARY KEY,
    username TEXT,
    first_name TEXT,
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notifications_enabled INTEGER DEFAULT 1,
    language TEXT DEFAULT 'en',
    last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
""")

# Bookmarks
cur.execute("""
CREATE TABLE IF NOT EXISTS bookmarks (
    user_id INTEGER,
    post_id TEXT,
    bookmarked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(user_id, post_id)
)
""")

# Feedback
cur.execute("""
CREATE TABLE IF NOT EXISTS feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status TEXT DEFAULT 'pending'
)
""")

# User activity log
cur.execute("""
CREATE TABLE IF NOT EXISTS user_activity (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    action TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
""")

conn.commit()
conn.close()
print("Database initialized successfully!")
