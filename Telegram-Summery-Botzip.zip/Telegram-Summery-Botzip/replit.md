# WABeta News Telegram Bot

## Overview
A Telegram bot that fetches WhatsApp news from wabetainfo.com RSS feed and posts to a Telegram channel with AI-powered summaries.

## Project Structure
```
Telegram-Bot/
├── main.py          # Main bot logic, handlers, and database functions
├── utils.py         # Utility functions for fetching articles, images, summarization
├── init_db.py       # Database initialization script
├── posts_history.db # SQLite database for posts and users
└── requirements.txt # Python dependencies
```

## Features
- RSS feed monitoring from wabetainfo.com
- Automatic posting to Telegram channel
- User subscriptions by category (Android, iOS, Windows, Web, General)
- Bookmark system
- Admin panel with stats and broadcast
- AI summarization using HuggingFace API (optional)

## Environment Variables
- `TELEGRAM_BOT_TOKEN` - Bot token from @BotFather
- `TELEGRAM_CHANNEL_ID` - Channel ID for posting
- `TELEGRAM_CHANNEL_USERNAME` - Channel username
- `TELEGRAM_ADMIN_ID` - Admin user ID
- `HUGGINGFACE_TOKEN` - Optional HuggingFace API token for AI summaries

## Commands
- `/start` - Start the bot and show welcome message
- `/menu` or `/panel` - Show main menu
- `/test` - Admin only: Test posting latest article

## Running
The bot runs with a Flask keep-alive server on port 5000 and polls Telegram for updates.
